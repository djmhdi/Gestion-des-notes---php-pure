<?php
echo $_POST["etudiant"];
?>